package com.example.ecommercetubes.ui.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.ecommercetubes.data.model.Product
import com.example.ecommercetubes.databinding.ItemProductBinding
import com.example.ecommercetubes.R

class ProductAdapter(
    private val role: String,
    private val onEdit: (Product) -> Unit,
    private val onDelete: (Product) -> Unit,
    private val onClick: (Product) -> Unit
) : ListAdapter<Product, ProductAdapter.ProductViewHolder>(DiffCallback()) {

    inner class ProductViewHolder(val binding: ItemProductBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val binding = ItemProductBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ProductViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        val product = getItem(position)
        holder.binding.apply {
            textProductName.text = product.name
            textProductPrice.text = "Rp${product.price}"

            Glide.with(root.context)
                .load(product.imageUrl)
                .placeholder(R.drawable.ic_launcher_background) // placeholder saat loading
                .into(imageProduct)

            fun showAdminOptionsDialog(context: Context, product: Product) {
                val options = arrayOf("Edit", "Hapus")
                AlertDialog.Builder(context)
                    .setTitle(product.name)
                    .setItems(options) { _, which ->
                        when (which) {
                            0 -> onEdit(product)
                            1 -> onDelete(product)
                        }
                    }
                    .show()
            }

            holder.itemView.setOnClickListener {
                if (role == "pegawai") {
                    showAdminOptionsDialog(holder.itemView.context, product)
                } else {
                    onClick(product)
                }
            }

        }
    }

    class DiffCallback : DiffUtil.ItemCallback<Product>() {
        override fun areItemsTheSame(oldItem: Product, newItem: Product) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: Product, newItem: Product) = oldItem == newItem
    }
}
