package com.example.ecommercetubes.ui.view

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.*
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.ecommercetubes.data.model.Order
import com.example.ecommercetubes.data.model.Product
import com.example.ecommercetubes.databinding.ActivityMainBinding
import com.example.ecommercetubes.ui.adapter.ProductAdapter
import com.example.ecommercetubes.ui.viewmodel.CartViewModel
import com.example.ecommercetubes.ui.viewmodel.ProductViewModel
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.util.*
import com.example.ecommercetubes.ui.view.EditProductActivity

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val productViewModel: ProductViewModel by viewModels()
    private val cartViewModel: CartViewModel by viewModels()

    private lateinit var adapter: ProductAdapter
    private var role: String = "user"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRole()
        setupUIByRole()
        setupRecyclerView()
        observeProducts()

        productViewModel.loadProducts()

        val categories = listOf("Semua", "Makanan", "Minuman")
        val adapterSpinner = ArrayAdapter(this, android.R.layout.simple_spinner_item, categories)
        adapterSpinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerCategory.adapter = adapterSpinner

        binding.spinnerCategory.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                when (categories[position]) {
                    "Semua" -> productViewModel.loadProducts()
                    "Makanan" -> productViewModel.loadProductsByCategory("makanan")
                    "Minuman" -> productViewModel.loadProductsByCategory("minuman")
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }
    }

    override fun onResume() {
        super.onResume()
        productViewModel.loadProducts()
    }

    private fun setupRole() {
        val prefs = getSharedPreferences("user_prefs", MODE_PRIVATE)
        role = prefs.getString("role", "user") ?: "user"
    }

    private fun setupUIByRole() {
        binding.btnViewOrders.visibility = if (role == "pegawai") View.VISIBLE else View.GONE
        binding.fabAddProduct.visibility = if (role == "pegawai") View.VISIBLE else View.GONE

        binding.btnCart.visibility = if (role == "user") View.VISIBLE else View.GONE
        binding.spinnerCategory.visibility = if (role == "user") View.VISIBLE else View.GONE

        binding.btnViewOrders.setOnClickListener {
            startActivity(Intent(this, OrderActivity::class.java))
        }

        binding.fabAddProduct.setOnClickListener {
            startActivity(Intent(this, AddProductActivity::class.java))
        }

        binding.btnCart.setOnClickListener {
            startActivity(Intent(this, CartActivity::class.java))
        }
    }

    private fun setupRecyclerView() {
        adapter = ProductAdapter(
            role = role,
            onEdit = { product ->
                val intent = Intent(this, EditProductActivity::class.java)
                intent.putExtra("product_id", product.id)
                startActivity(intent)
            },
            onDelete = { product ->
                MaterialAlertDialogBuilder(this)
                    .setTitle("Hapus Produk")
                    .setMessage("Yakin ingin menghapus \"${product.name}\"?")
                    .setPositiveButton("Hapus") { _, _ ->
                        productViewModel.deleteProduct(product)
                        Toast.makeText(this, "Produk dihapus", Toast.LENGTH_SHORT).show()
                    }
                    .setNegativeButton("Batal", null)
                    .show()
            },
            onClick = { product ->
                showQuantityDialog(product)
            }
        )
        binding.recyclerViewProducts.layoutManager = LinearLayoutManager(this)
        binding.recyclerViewProducts.adapter = adapter
    }

    private fun observeProducts() {
        binding.progressBar.visibility = View.VISIBLE
        lifecycleScope.launch {
            productViewModel.products.collectLatest { products ->
                binding.progressBar.visibility = View.GONE
                binding.recyclerViewProducts.visibility = View.VISIBLE
                adapter.submitList(products)
            }
        }
    }

    private fun showQuantityDialog(product: Product) {
        val prefs = getSharedPreferences("user_prefs", MODE_PRIVATE)
        val userName = prefs.getString("user_name", "Guest") ?: "Guest"
        val tableNumber = prefs.getString("table_number", "0") ?: "0"

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 10)
        }

        val quantityInput = EditText(this).apply {
            hint = "Jumlah"
            inputType = InputType.TYPE_CLASS_NUMBER
        }

        layout.addView(quantityInput)

        MaterialAlertDialogBuilder(this)
            .setTitle("Tambah ke Keranjang")
            .setMessage("Masukkan jumlah untuk produk \"${product.name}\"")
            .setView(layout)
            .setPositiveButton("Tambah") { _, _ ->
                val quantity = quantityInput.text.toString().toIntOrNull() ?: 1

                val order = Order(
                    id = 0,
                    userId = 1,
                    productId = product.id,
                    quantity = quantity,
                    status = "pending",
                    userName = userName,
                    tableNumber = tableNumber,
                    productName = product.name,
                    productPrice = product.price.toInt(),
                    orderGroupId = UUID.randomUUID().toString()
                )

                cartViewModel.addToCart(order)
                Toast.makeText(this, "${product.name} ($quantity) ditambahkan ke keranjang", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null)
            .show()
    }
}
