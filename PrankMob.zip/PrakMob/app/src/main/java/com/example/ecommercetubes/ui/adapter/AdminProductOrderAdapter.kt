package com.example.ecommercetubes.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.ecommercetubes.data.model.Product
import com.example.ecommercetubes.databinding.ItemAddOrderProductBinding


class AdminProductOrderAdapter(
    private val products: MutableList<Product>,
    private val qtyMap: MutableMap<Int, Int>
) : RecyclerView.Adapter<AdminProductOrderAdapter.ProductViewHolder>() {

    inner class ProductViewHolder(val binding: ItemAddOrderProductBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(product: Product) {
            binding.tvProductName.text = product.name
            binding.numberPicker.apply {
                minValue = 0
                maxValue = 20
                value = qtyMap[product.id] ?: 0
                setOnValueChangedListener { _, _, newVal ->
                    qtyMap[product.id] = newVal
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val binding = ItemAddOrderProductBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ProductViewHolder(binding)
    }

    override fun getItemCount() = products.size

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        holder.bind(products[position])
    }

    fun getSelectedItems(): List<Pair<Product, Int>> {
        return qtyMap.filter { it.value > 0 }.mapNotNull { (id, qty) ->
            val product = products.find { it.id == id }
            product?.let { it to qty }
        }
    }

    fun updateProducts(newProducts: List<Product>) {
        (products as MutableList).clear()
        (products as MutableList).addAll(newProducts)
        notifyDataSetChanged()
    }
}
