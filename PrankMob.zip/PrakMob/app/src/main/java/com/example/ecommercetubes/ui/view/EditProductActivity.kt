package com.example.ecommercetubes.ui.view

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.ecommercetubes.data.model.Product
import com.example.ecommercetubes.databinding.ActivityAddProductBinding
import com.example.ecommercetubes.ui.viewmodel.ProductViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class EditProductActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddProductBinding
    private val productViewModel: ProductViewModel by viewModels()

    private var productId: Int = -1
    private var currentProduct: Product? = null
    private var selectedCategory: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddProductBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Spinner kategori
        val categories = listOf("makanan", "minuman")
        val spinnerAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, categories)
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerCategory.adapter = spinnerAdapter

        // Ambil productId dari intent
        productId = intent.getIntExtra("product_id", -1)
        if (productId == -1) {
            Toast.makeText(this, "Produk tidak ditemukan", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        // Load produk dari ViewModel
        productViewModel.products.value.find { it.id == productId }?.let { product ->
            currentProduct = product
            binding.etName.setText(product.name)
            binding.etPrice.setText(product.price.toString())
            binding.etDescription.setText(product.description ?: "")
            selectedCategory = product.category
            binding.spinnerCategory.setSelection(categories.indexOf(product.category))

            product.imageUrl?.let {
                Glide.with(this).load(it).into(binding.imagePreview)
            }
        }

        binding.btnSave.setOnClickListener {
            updateProduct()
        }
    }

    private fun updateProduct() {
        val name = binding.etName.text.toString()
        val price = binding.etPrice.text.toString().toDoubleOrNull()
        val description = binding.etDescription.text.toString()
        val category = binding.spinnerCategory.selectedItem.toString()

        if (name.isBlank() || price == null) {
            Toast.makeText(this, "Nama dan harga harus diisi", Toast.LENGTH_SHORT).show()
            return
        }

        val updatedProduct = currentProduct?.copy(
            name = name,
            price = price,
            description = if (description.isBlank()) null else description,
            category = category
        )

        if (updatedProduct != null) {
            productViewModel.updateProduct(updatedProduct)
            Toast.makeText(this, "Produk diperbarui", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
