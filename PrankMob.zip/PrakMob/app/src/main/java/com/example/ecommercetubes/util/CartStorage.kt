package com.example.ecommercetubes.util

import com.example.ecommercetubes.data.model.Order

object CartStorage {
    private val cartItems = mutableListOf<Order>()

    fun getItems(): List<Order> = cartItems.toList()

    fun addItem(order: Order) {
        cartItems.add(order)
    }

    fun removeItem(order: Order) {
        cartItems.remove(order)
    }

    fun clear() {
        cartItems.clear()
    }
}
