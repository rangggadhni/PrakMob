package com.example.ecommercetubes.ui.view

import android.content.Intent
import android.os.Bundle
import android.util.Pair
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.ecommercetubes.R
import com.example.ecommercetubes.data.model.Order
import com.example.ecommercetubes.data.model.Product
import com.example.ecommercetubes.databinding.ActivityOrderBinding
import com.example.ecommercetubes.ui.adapter.AdminProductOrderAdapter
import com.example.ecommercetubes.ui.adapter.OrderAdapter
import com.example.ecommercetubes.ui.viewmodel.OrderViewModel
import com.example.ecommercetubes.ui.viewmodel.ProductViewModel
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.util.UUID

@AndroidEntryPoint
class OrderActivity : AppCompatActivity() {

    private lateinit var binding: ActivityOrderBinding
    private val orderViewModel: OrderViewModel by viewModels()
    private val adapter = OrderAdapter { updatedOrder ->
        orderViewModel.updateOrder(updatedOrder)
    }
    private val productViewModel: ProductViewModel by viewModels()
    lateinit var adminAdapter: AdminProductOrderAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOrderBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.rvOrders.layoutManager = LinearLayoutManager(this)
        binding.rvOrders.adapter = adapter

        orderViewModel.loadOrders()

        lifecycleScope.launch {
            orderViewModel.orders.collectLatest { orders ->
                val grouped = orders
                    .groupBy { it.orderGroupId }
                    .map { (_, orderList) ->
                        val first = orderList.first()
                        val combinedProductNames = orderList.joinToString(", ") {
                            "${it.productName} (${it.quantity})"
                        }
                        val totalQty = orderList.sumOf { it.quantity }
                        val totalPrice = orderList.sumOf { it.quantity * it.productPrice }

                        first.copy(
                            productName = combinedProductNames,
                            quantity = totalQty,
                            productPrice = totalPrice
                        )
                    }

                adapter.submitList(grouped) // ← Di sinilah dipanggil!
            }
        }

        binding.btnAddOrder.setOnClickListener {
            showAddOrderDialog()
            // ATAU:
            //startActivity(Intent(this, AddOrderByAdminActivity::class.java))
        }

        productViewModel.loadProducts()
    }

    private fun showAddOrderDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_add_order, null)
        val recyclerView = dialogView.findViewById<RecyclerView>(R.id.recyclerViewProducts)
        val btnOrder = dialogView.findViewById<Button>(R.id.btnSubmitOrder)
        val inputTableNumber = dialogView.findViewById<EditText>(R.id.editTextTableNumber)

        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle("Tambah Order")
            .setView(dialogView)
            .setNegativeButton("Batal", null)
            .create()

        lifecycleScope.launch {
            productViewModel.products.collectLatest { products ->
                adminAdapter = AdminProductOrderAdapter(products.toMutableList(), mutableMapOf())
                recyclerView.layoutManager = LinearLayoutManager(this@OrderActivity)
                recyclerView.adapter = adminAdapter
            }
        }

        btnOrder.setOnClickListener {
            val tableNumber = inputTableNumber.text.toString().trim()
            if (tableNumber.isEmpty()) {
                Toast.makeText(this, "Nomor meja wajib diisi", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val selectedItems = adminAdapter.getSelectedItems()
            if (selectedItems.isEmpty()) {
                Toast.makeText(this, "Pilih produk terlebih dahulu", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val prefs = getSharedPreferences("user_prefs", MODE_PRIVATE)
            val userName = prefs.getString("user_name", "Admin") ?: "Admin"
            val groupId = UUID.randomUUID().toString()

            for ((product, qty) in selectedItems) {
                val order = Order(
                    id = 0,
                    userId = 1,
                    productId = product.id,
                    quantity = qty,
                    status = "pending",
                    userName = userName,
                    tableNumber = tableNumber,
                    productName = product.name,
                    productPrice = product.price.toInt(),
                    orderGroupId = groupId
                )
                orderViewModel.addOrder(order)
            }

            Toast.makeText(this, "Order berhasil ditambahkan", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }
        dialog.show()
    }
}
