package com.example.ecommercetubes.di

import android.content.Context
import androidx.room.Room
import com.example.ecommercetubes.data.dao.OrderDao
import com.example.ecommercetubes.data.dao.ProductDao
import com.example.ecommercetubes.data.dao.UserDao
import com.example.ecommercetubes.data.database.AppDatabase
import com.example.ecommercetubes.repository.OrderRepository
import com.example.ecommercetubes.repository.ProductRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    // Provide AppDatabase instance
    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext appContext: Context): AppDatabase {
        return Room.databaseBuilder(
            appContext,
            AppDatabase::class.java,
            "products_database"
        )
            .fallbackToDestructiveMigration() // Hindari crash saat versi DB berubah
            .build()
    }

    // Provide DAO
    @Provides
    fun provideProductDao(database: AppDatabase): ProductDao = database.productDao()
    @Provides
    fun provideOrderDao(database: AppDatabase): OrderDao = database.orderDao()
    @Provides
    fun provideUserDao(database: AppDatabase): UserDao = database.userDao()

    // Provide Repository
    @Provides
    fun provideProductRepository(productDao: ProductDao): ProductRepository =
        ProductRepository(productDao)

    @Provides
    fun provideOrderRepository(orderDao: OrderDao): OrderRepository =
        OrderRepository(orderDao)

}
