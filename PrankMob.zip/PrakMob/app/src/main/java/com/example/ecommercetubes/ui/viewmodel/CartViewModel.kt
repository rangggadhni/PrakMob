package com.example.ecommercetubes.ui.viewmodel

import androidx.lifecycle.ViewModel
import com.example.ecommercetubes.data.model.Order
import com.example.ecommercetubes.util.CartStorage
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject

@HiltViewModel
class CartViewModel @Inject constructor() : ViewModel() {

    private val _cartItems = MutableStateFlow(CartStorage.getItems())
    val cartItems: StateFlow<List<Order>> = _cartItems

    fun addToCart(order: Order) {
        CartStorage.addItem(order)
        _cartItems.value = CartStorage.getItems()
    }

    fun removeFromCart(order: Order) {
        CartStorage.removeItem(order)
        _cartItems.value = CartStorage.getItems()
    }

    fun clearCart() {
        CartStorage.clear()
        _cartItems.value = emptyList()
    }
}
