package com.example.ecommercetubes.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.NumberPicker
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.ecommercetubes.data.model.Product
import com.example.ecommercetubes.databinding.ItemAddOrderProductBinding

class AddOrderAdapter :
    ListAdapter<Product, AddOrderAdapter.ProductViewHolder>(DiffCallback()) {

    private val qtyMap = mutableMapOf<Int, Int>()

    inner class ProductViewHolder(val binding: ItemAddOrderProductBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(product: Product) {
            binding.tvProductName.text = product.name
            binding.numberPicker.apply {
                minValue = 0
                maxValue = 999
                value = qtyMap[product.id] ?: 0
                setOnValueChangedListener { _, _, newVal ->
                    qtyMap[product.id] = newVal
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val binding = ItemAddOrderProductBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ProductViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    fun getSelectedItems(): Map<Product, Int> {
        return currentList
            .filter { qtyMap[it.id] ?: 0 > 0 }
            .associateWith { qtyMap[it.id] ?: 0 }
    }

    class DiffCallback : DiffUtil.ItemCallback<Product>() {
        override fun areItemsTheSame(oldItem: Product, newItem: Product) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: Product, newItem: Product) = oldItem == newItem
    }
}
