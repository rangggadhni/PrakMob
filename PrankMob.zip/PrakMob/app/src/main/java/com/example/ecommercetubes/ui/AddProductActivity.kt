package com.example.ecommercetubes.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.ecommercetubes.data.database.AppDatabase
import com.example.ecommercetubes.data.model.Product
import com.example.ecommercetubes.databinding.ActivityAddProductBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AddProductActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddProductBinding
    private val dao by lazy { AppDatabase.getInstance(this).productDao() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddProductBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSave.setOnClickListener {
            val name = binding.etName.text.toString().trim()
            val price = binding.etPrice.text.toString().trim().toDoubleOrNull()
            val desc = binding.etDescription.text.toString().trim()

            if (name.isEmpty()) {
                Toast.makeText(this, "Nama produk harus diisi", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (price == null) {
                Toast.makeText(this, "Harga produk harus berupa angka yang valid", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val product = Product(
                name = name,
                price = price,
                description = if (desc.isEmpty()) null else desc,
                imageUrl = null,  // nanti bisa diupdate kalau ada gambar
                category = null.toString()
            )

            // Insert produk di background thread yang lifecycle-aware
            lifecycleScope.launch(Dispatchers.IO) {
                dao.insertProduct(product)

                // Balik ke UI thread untuk tampilkan Toast dan finish Activity
                launch(Dispatchers.Main) {
                    Toast.makeText(this@AddProductActivity, "Produk berhasil ditambahkan!", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
        }
    }
}
