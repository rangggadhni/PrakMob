package com.example.ecommercetubes.ui.view

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.ecommercetubes.data.model.Order
import com.example.ecommercetubes.databinding.ActivityCartBinding
import com.example.ecommercetubes.ui.adapter.CartAdapter
import com.example.ecommercetubes.ui.viewmodel.CartViewModel
import com.example.ecommercetubes.ui.viewmodel.OrderViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.util.UUID

@AndroidEntryPoint
class CartActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCartBinding
    private val cartViewModel: CartViewModel by viewModels()
    private val orderViewModel: OrderViewModel by viewModels()
    private lateinit var adapter: CartAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCartBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = CartAdapter { order ->
            cartViewModel.removeFromCart(order)
        }

        binding.recyclerViewCart.layoutManager = LinearLayoutManager(this)
        binding.recyclerViewCart.adapter = adapter

        lifecycleScope.launch {
            cartViewModel.cartItems.collectLatest { items ->
                adapter.submitList(items)

                // Tampilkan/hilangkan teks keranjang kosong
                binding.tvEmptyCart.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE

                // Aktif/nonaktifkan tombol pesan
                binding.btnConfirmOrder.isEnabled = items.isNotEmpty()

                // Hitung total harga
                val totalPrice = items.sumOf { it.productPrice * it.quantity }

                // Tampilkan total harga
                binding.tvTotalPrice.text = "Total: Rp$totalPrice"
            }

        }


        // Tombol Konfirmasi Pesanan
        binding.btnConfirmOrder.setOnClickListener {
            lifecycleScope.launch {
                val items = cartViewModel.cartItems.value
                if (items.isEmpty()) {
                    Toast.makeText(this@CartActivity, "Keranjang masih kosong", Toast.LENGTH_SHORT)
                        .show()
                    return@launch
                }

                val prefs = getSharedPreferences("user_prefs", MODE_PRIVATE)
                val userName = prefs.getString("user_name", "User") ?: "User"
                val tableNumber = prefs.getString("table_number", "-") ?: "-"

                val groupId = UUID.randomUUID().toString() // ← Generate satu ID grup

                items.forEach { item ->
                    val order = Order(
                        id = 0,
                        userId = 1,
                        productId = item.productId,
                        quantity = item.quantity,
                        status = "pending",
                        userName = userName,
                        tableNumber = tableNumber,
                        productName = item.productName,
                        productPrice = item.productPrice,
                        orderGroupId = groupId // ← Assign di sini
                    )
                    orderViewModel.addOrder(order)
                }
                cartViewModel.clearCart()
                Toast.makeText(this@CartActivity, "Pesanan berhasil dikonfirmasi!", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }
}
