package com.example.ecommercetubes.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.ecommercetubes.data.model.Order
import com.example.ecommercetubes.data.model.Product
import com.example.ecommercetubes.databinding.ItemOrderBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder

// Di OrderAdapter.kt
class OrderAdapter(
    private val onOrderChecked: (Order) -> Unit
) : ListAdapter<Order, OrderAdapter.OrderViewHolder>(DiffCallback()) {

    inner class OrderViewHolder(val binding: ItemOrderBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OrderViewHolder {
        val binding = ItemOrderBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return OrderViewHolder(binding)
    }

    override fun onBindViewHolder(holder: OrderViewHolder, position: Int) {
        val order = getItem(position)
        holder.binding.apply {
            textOrderId.text = "Order ID: ${order.id}"
            textOrderUser.text = "Nama: ${order.userName} | Meja: ${order.tableNumber}"
            textOrderProduct.text = "Produk: ${order.productName}"
            textOrderQuantity.text = "Qty: ${order.quantity} | Total: Rp${order.productPrice}"

            checkBoxComplete.isChecked = order.status == "completed"
            checkBoxComplete.isEnabled = order.status != "completed"

            // 💡 Atur transparansi berdasarkan status:
            root.alpha = if (order.status == "completed") 0.5f else 1.0f

            checkBoxComplete.setOnClickListener {
                if (checkBoxComplete.isChecked) {
                    MaterialAlertDialogBuilder(holder.itemView.context)
                        .setTitle("Konfirmasi Selesai")
                        .setMessage("Tandai order ini sebagai selesai?")
                        .setPositiveButton("Ya") { _, _ ->
                            val updatedOrder = order.copy(status = "completed")
                            onOrderChecked(updatedOrder)

                            checkBoxComplete.isEnabled = false
                            root.alpha = 0.5f
                        }
                        .setNegativeButton("Batal") { _, _ ->
                            checkBoxComplete.isChecked = false
                        }
                        .show()
                }
            }
        }
    }

}

class DiffCallback : DiffUtil.ItemCallback<Order>() {
    override fun areItemsTheSame(oldItem: Order, newItem: Order) = oldItem.id == newItem.id
    override fun areContentsTheSame(oldItem: Order, newItem: Order) = oldItem == newItem
}