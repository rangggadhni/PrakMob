package com.example.ecommercetubes.data.dao

import androidx.room.*
import com.example.ecommercetubes.data.model.Order

@Dao
interface OrderDao {

    @Query("SELECT * FROM orders")
    suspend fun getAllOrders(): List<Order>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: Order)

    @Delete
    suspend fun deleteOrder(order: Order)

    @Update
    suspend fun updateOrder(order: Order)

}
