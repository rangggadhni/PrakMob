package com.example.ecommercetubes.ui.view

import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.ecommercetubes.data.model.Order
import com.example.ecommercetubes.databinding.ActivityAddOrderByAdminBinding
import com.example.ecommercetubes.ui.adapter.AdminProductOrderAdapter
import com.example.ecommercetubes.ui.viewmodel.CartViewModel
import com.example.ecommercetubes.ui.viewmodel.ProductViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@AndroidEntryPoint
class AddOrderByAdminActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddOrderByAdminBinding
    private val productViewModel: ProductViewModel by viewModels()
    private val cartViewModel: CartViewModel by viewModels()

    private lateinit var adapter: AdminProductOrderAdapter
    private val qtyMap: MutableMap<Int, Int> = mutableMapOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddOrderByAdminBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Setup RecyclerView
        adapter = AdminProductOrderAdapter(mutableListOf(), mutableMapOf())
        binding.recyclerViewProducts.layoutManager = LinearLayoutManager(this)
        binding.recyclerViewProducts.adapter = adapter

        // Observe product list
        lifecycleScope.launch {
            productViewModel.products.collectLatest { products ->
                adapter.updateProducts(products)
            }
        }

        // Tombol Pesan
        binding.btnPlaceOrder.setOnClickListener {
            val tableNumber = binding.editTextTableNumber.text.toString().trim()

            if (tableNumber.isEmpty()) {
                Toast.makeText(this, "Nomor meja tidak boleh kosong", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val items = adapter.getSelectedItems()

            if (items.isEmpty()) {
                Toast.makeText(this, "Tidak ada produk yang dipilih", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            for ((product, qty) in items) {
                val order = Order(
                    id = 0,
                    userId = 999,
                    productId = product.id,
                    quantity = qty,
                    status = "pending",
                    userName = "Admin",
                    tableNumber = tableNumber,
                    productName = product.name,
                    productPrice = product.price.toInt(),
                    orderGroupId = String()
                )
                cartViewModel.addToCart(order)
            }

            Toast.makeText(this, "Pesanan berhasil ditambahkan", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}