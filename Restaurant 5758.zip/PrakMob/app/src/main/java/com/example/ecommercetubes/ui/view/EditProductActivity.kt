package com.example.ecommercetubes.ui.view

import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.example.ecommercetubes.data.model.Product
import com.example.ecommercetubes.databinding.ActivityAddProductBinding
import com.example.ecommercetubes.ui.viewmodel.ProductViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@AndroidEntryPoint
class EditProductActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddProductBinding
    private val productViewModel: ProductViewModel by viewModels()

    private var productId: Int = -1
    private var currentProduct: Product? = null
    private var selectedImageUri: Uri? = null

    private val pickImageLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            selectedImageUri = it
            Glide.with(this).load(it).into(binding.imagePreview)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddProductBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Setup spinner kategori
        val categoryList = listOf("makanan", "minuman")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, categoryList)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerCategory.adapter = adapter

        // Ambil ID produk dari intent
        productId = intent.getIntExtra("product_id", -1)
        if (productId == -1) {
            Toast.makeText(this, "Produk tidak ditemukan", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        // Load produk
        productViewModel.loadProducts()

        // Observasi dan isi data produk
        lifecycleScope.launch {
            productViewModel.products.collectLatest { productList ->
                val product = productList.find { it.id == productId }
                if (product != null) {
                    currentProduct = product
                    binding.etName.setText(product.name)
                    binding.etPrice.setText(product.price.toString())
                    binding.etDescription.setText(product.description ?: "")
                    binding.spinnerCategory.setSelection(categoryList.indexOf(product.category))
                    product.imageUrl?.let {
                        selectedImageUri = Uri.parse(it)
                        Glide.with(this@EditProductActivity).load(it).into(binding.imagePreview)
                    }
                }
            }
        }

        // Tombol pilih gambar
        binding.btnPickImage.setOnClickListener {
            pickImageLauncher.launch("image/*")
        }

        // Tombol simpan
        binding.btnSave.setOnClickListener {
            saveChanges()
        }
    }

    private fun saveChanges() {
        val product = requireNotNull(currentProduct) { "Produk tidak boleh null saat update." }

        val name = binding.etName.text.toString().trim()
        val price = binding.etPrice.text.toString().toDoubleOrNull()
        val description = binding.etDescription.text.toString().trim()
        val category = binding.spinnerCategory.selectedItem.toString()

        if (name.isEmpty() || price == null) {
            Toast.makeText(this, "Nama dan harga harus diisi", Toast.LENGTH_SHORT).show()
            return
        }

        val updatedProduct = product.copy(
            name = name,
            price = price,
            description = if (description.isEmpty()) null else description,
            imageUrl = selectedImageUri?.toString(),
            category = category
        )

        productViewModel.updateProduct(updatedProduct)
        Toast.makeText(this, "Produk berhasil diperbarui", Toast.LENGTH_SHORT).show()
        finish()
    }
}
