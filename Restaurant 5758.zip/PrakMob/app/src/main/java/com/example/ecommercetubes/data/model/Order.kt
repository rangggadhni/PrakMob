package com.example.ecommercetubes.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "orders")
data class Order(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long,
    val productId: Int,
    val quantity: Int,
    val status: String, // pending, completed
    val userName: String,
    val tableNumber: String,
    val productName: String,
    val productPrice: Int,
    val orderGroupId: String
)
