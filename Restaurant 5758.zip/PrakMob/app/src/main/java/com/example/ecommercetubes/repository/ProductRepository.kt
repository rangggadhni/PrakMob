package com.example.ecommercetubes.repository

import com.example.ecommercetubes.data.dao.ProductDao
import com.example.ecommercetubes.data.model.Product
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow


@Singleton
class ProductRepository @Inject constructor(private val productDao: ProductDao) {
    fun getProducts(): Flow<List<Product>> {
        return productDao.getAllProducts()
    }

    fun getProductsFlow(): Flow<List<Product>> = productDao.getProductsFlow()

    fun getProductsByCategory(category: String): Flow<List<Product>> =
        productDao.getProductsByCategory(category)

    suspend fun addProduct(product: Product) {
        productDao.insertProduct(product)
    }

    suspend fun deleteProduct(product: Product) {
        productDao.deleteProduct(product)
    }
    suspend fun updateProduct(product: Product) {
        productDao.updateProduct(product)
    }
}

