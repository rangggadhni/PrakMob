package com.example.ecommercetubes.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.ecommercetubes.data.dao.OrderDao
import com.example.ecommercetubes.data.dao.ProductDao
import com.example.ecommercetubes.data.dao.UserDao
import com.example.ecommercetubes.data.model.Order
import com.example.ecommercetubes.data.model.Product
import com.example.ecommercetubes.data.model.User

@Database(entities = [Product::class, Order::class, User::class], version = 3)
abstract class AppDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
    abstract fun orderDao(): OrderDao
    abstract fun userDao(): UserDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "products_database"
                )
                    .fallbackToDestructiveMigration() // Tambahkan ini
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
