package com.example.ecommercetubes.repository

import com.example.ecommercetubes.data.dao.UserDao
import com.example.ecommercetubes.data.model.User
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class UserRepository @Inject constructor(
    private val userDao: UserDao
) {
    suspend fun getUsers(): List<User> = userDao.getAllUsers()

    suspend fun addUser(user: User) = userDao.insertUser(user)

    suspend fun deleteUser(user: User) = userDao.deleteUser(user)
}
