package com.example.ecommercetubes.repository

import com.example.ecommercetubes.data.dao.OrderDao
import com.example.ecommercetubes.data.model.Order
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class OrderRepository @Inject constructor(
    private val orderDao: OrderDao
) {
    suspend fun getOrders(): List<Order> = orderDao.getAllOrders()

    suspend fun addOrder(order: Order) = orderDao.insertOrder(order)

    suspend fun deleteOrder(order: Order) = orderDao.deleteOrder(order)

    suspend fun updateOrder(order: Order) {
        orderDao.updateOrder(order)
    }

}
