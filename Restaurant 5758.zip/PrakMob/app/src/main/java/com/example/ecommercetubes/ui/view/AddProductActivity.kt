package com.example.ecommercetubes.ui.view

import android.R
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.ecommercetubes.data.model.Product
import com.example.ecommercetubes.databinding.ActivityAddProductBinding
import com.example.ecommercetubes.ui.viewmodel.ProductViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class AddProductActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddProductBinding
    private val productViewModel: ProductViewModel by viewModels()

    private var selectedImageUri: Uri? = null

    private val pickImageLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            selectedImageUri = it
            Glide.with(this)
                .load(it)
                .into(binding.imagePreview)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddProductBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnPickImage.setOnClickListener {
            pickImageLauncher.launch("image/*")
        }

        binding.btnSave.setOnClickListener {
            saveProduct()
        }

        val categoryOptions = listOf("makanan", "minuman")
        val adapter = ArrayAdapter(this, R.layout.simple_spinner_item, categoryOptions)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerCategory.adapter = adapter

    }

    private fun saveProduct() {
        val name = binding.etName.text.toString().trim()
        val priceText = binding.etPrice.text.toString().trim()
        val description = binding.etDescription.text.toString().trim()
        val selectedCategory = binding.spinnerCategory.selectedItem.toString()

        if (name.isEmpty()) {
            Toast.makeText(this, "Nama produk harus diisi", Toast.LENGTH_SHORT).show()
            return
        }

        if (priceText.isEmpty()) {
            Toast.makeText(this, "Harga produk harus diisi", Toast.LENGTH_SHORT).show()
            return
        }

        val price = priceText.toDoubleOrNull()
        if (price == null) {
            Toast.makeText(this, "Harga produk harus berupa angka yang valid", Toast.LENGTH_SHORT).show()
            return
        }

        val product = Product(
            name = name,
            price = price,
            description = if (description.isEmpty()) null else description,
            imageUrl = selectedImageUri?.toString(),
            category = selectedCategory
        )

        productViewModel.addProduct(product)

        Toast.makeText(this, "Produk berhasil disimpan", Toast.LENGTH_SHORT).show()
        finish()
    }
}
